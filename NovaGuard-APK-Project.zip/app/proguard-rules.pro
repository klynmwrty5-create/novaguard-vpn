-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keep class com.tunweb.wireguard.** { *; }
-keep class com.wireguard.** { *; }
-keep class com.journeyapps.** { *; }
-keep class com.google.zxing.** { *; }
-keep class hev.htproxy.** { *; }

-dontwarn javax.annotation.**
-dontwarn com.google.errorprone.**
-dontwarn org.checkerframework.**
-dontwarn org.slf4j.**
-dontwarn dalvik.system.**
-ignorewarnings
