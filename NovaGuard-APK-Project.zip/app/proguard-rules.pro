-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keep class com.tunweb.wireguard.** { *; }
-keep class com.wireguard.** { *; }
-keep class com.journeyapps.** { *; }
-keep class com.google.zxing.** { *; }
-keep class hev.htproxy.** { *; }
