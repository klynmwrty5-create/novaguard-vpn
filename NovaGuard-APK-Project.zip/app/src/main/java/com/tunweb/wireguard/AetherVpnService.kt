package com.tunweb.wireguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import hev.htproxy.TProxyService
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class AetherVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.tunweb.wireguard.AETHER_START"
        const val ACTION_STOP = "com.tunweb.wireguard.AETHER_STOP"
        const val ACTION_EVENT = "com.tunweb.wireguard.AETHER_EVENT"

        const val EXTRA_PROTOCOL = "protocol"
        const val EXTRA_SCAN = "scan"
        const val EXTRA_NOIZE = "noize"
        const val EXTRA_MTU = "mtu"
        const val EXTRA_FRAGMENT = "fragment"
        const val EXTRA_DNS = "dns"
        const val EXTRA_EXCLUDED_APPS = "excluded_apps"

        const val EVENT_TYPE = "type"
        const val EVENT_STATE = "state"
        const val EVENT_MESSAGE = "message"
        const val EVENT_RX = "rx"
        const val EVENT_TX = "tx"

        private const val CHANNEL_ID = "novaguard_aether_vpn"
        private const val NOTIF_ID = 8018
        private const val SOCKS_PORT = 1819

        @Volatile
        var isServiceRunning: Boolean = false
            private set

        @Volatile
        var currentState: String = "disconnected"
            private set
    }

    private val workerExecutor = Executors.newSingleThreadExecutor()
    private val statsScheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var statsTask: ScheduledFuture<*>? = null

    private var aetherProcess: Process? = null
    private var tunInterface: ParcelFileDescriptor? = null
    private val stopping = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAetherTunnel("اتصال Aether قطع شد.")
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val protocol = intent.getStringExtra(EXTRA_PROTOCOL) ?: "masque"
                val scan = intent.getStringExtra(EXTRA_SCAN) ?: "turbo"
                val noize = intent.getStringExtra(EXTRA_NOIZE) ?: "firewall"
                val mtu = intent.getIntExtra(EXTRA_MTU, 1280).coerceIn(1200, 1500)
                val fragment = intent.getBooleanExtra(EXTRA_FRAGMENT, false)
                val dns = intent.getStringExtra(EXTRA_DNS) ?: "1.1.1.1, 8.8.8.8"
                val excluded = intent.getStringExtra(EXTRA_EXCLUDED_APPS) ?: ""

                createNotificationChannel()
                val notif = buildNotification("Aether (${protocol.uppercase()}) در حال اتصال...")
                try {
                    if (Build.VERSION.SDK_INT >= 34) {
                        startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                    } else {
                        startForeground(NOTIF_ID, notif)
                    }
                } catch (_: Exception) {
                }
                startAetherTunnel(protocol, scan, noize, mtu, fragment, dns, excluded)
                return START_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun startAetherTunnel(
        protocol: String,
        scan: String,
        noize: String,
        mtu: Int,
        fragment: Boolean,
        dnsCsv: String,
        excludedCsv: String
    ) {
        stopping.set(false)
        workerExecutor.execute {
            cleanupCoreOnly()
            isServiceRunning = true
            emitState("connecting", "شروع هسته Aether ($protocol · $scan)...")

            try {
                val aetherBin = File(applicationInfo.nativeLibraryDir, "libaether.so")
                if (!aetherBin.exists()) {
                    throw IllegalStateException("باینری libaether.so در این نسخه نصب نشده است.")
                }

                val workDir = File(filesDir, "aether").apply { mkdirs() }
                val cmd = mutableListOf(
                    aetherBin.absolutePath,
                    "--bind", "127.0.0.1:$SOCKS_PORT",
                    "-4",
                    "--quick-reconnect"
                )

                when (protocol) {
                    "masque_h2" -> {
                        cmd.add("--masque")
                        cmd.add("--h2")
                        cmd.add("--fragment")
                    }
                    "gool" -> {
                        cmd.add("--gool")
                        if (fragment) cmd.add("--fragment")
                    }
                    "wg" -> {
                        cmd.add("--wg")
                    }
                    "gool_classic" -> {
                        cmd.add("--gool-classic")
                    }
                    else -> {
                        cmd.add("--masque")
                        if (fragment) cmd.add("--fragment")
                    }
                }

                val validScan = when (scan) {
                    "turbo", "balanced", "thorough", "stealth", "ironclad" -> scan
                    else -> "turbo"
                }
                cmd.add("--scan")
                cmd.add(validScan)

                val validNoize = when (protocol) {
                    "wg", "gool_classic" -> if (noize in listOf("balanced", "aggressive", "light", "off")) noize else "balanced"
                    else -> if (noize in listOf("firewall", "gfw", "off")) noize else "firewall"
                }
                cmd.add("--noize")
                cmd.add(validNoize)

                emitLog("CMD: ${cmd.joinToString(" ")}")

                val pb = ProcessBuilder(cmd).apply {
                    directory(workDir)
                    redirectErrorStream(true)
                    environment()["AETHER_QUICK_RECONNECT"] = "1"
                    environment()["AETHER_SOCKS"] = "127.0.0.1:$SOCKS_PORT"
                    environment()["HOME"] = workDir.absolutePath
                }

                val proc = pb.start()
                aetherProcess = proc
                try { proc.outputStream.close() } catch (_: Exception) {}

                // Stream Aether output asynchronously
                Thread({
                    try {
                        proc.inputStream.bufferedReader().useLines { lines ->
                            lines.forEach { line ->
                                val trimmed = line.trim()
                                if (trimmed.isNotEmpty()) emitLog("[Aether] $trimmed")
                            }
                        }
                    } catch (_: Exception) {
                    }
                }, "aether-log-reader").start()

                // Wait for Aether SOCKS5 port (127.0.0.1:1819) to become ready
                val ready = waitForSocksReady(proc, timeoutMs = 75_000L)
                if (!ready || stopping.get()) {
                    if (!stopping.get()) {
                        throw IllegalStateException("هسته Aether نتوانست درگام سالم کلودفلر پیدا کند یا بسته شد.")
                    }
                    return@execute
                }

                // Build TUN interface
                val builder = Builder()
                    .setSession("NovaGuard Aether")
                    .setMtu(mtu)
                    .addAddress("198.18.0.1", 24)
                    .addRoute("0.0.0.0", 0)

                val dnsList = dnsCsv.split(",")
                    .map { it.trim() }
                    .filter { it.matches(Regex("^\\d+\\.\\d+\\.\\d+\\.\\d+$")) }
                if (dnsList.isNotEmpty()) {
                    dnsList.forEach { builder.addDnsServer(it) }
                } else {
                    builder.addDnsServer("1.1.1.1")
                    builder.addDnsServer("8.8.8.8")
                }

                // Prevent routing loop: Aether sockets must bypass TUN
                try {
                    builder.addDisallowedApplication(packageName)
                } catch (_: Exception) {
                }

                excludedCsv.split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() && it != packageName }
                    .forEach { pkg ->
                        try { builder.addDisallowedApplication(pkg) } catch (_: Exception) {}
                    }

                val pfd = builder.establish()
                    ?: throw IllegalStateException("ایجاد رابط TUN توسط سیستم‌عامل رد شد.")
                tunInterface = pfd

                val yamlFile = File(filesDir, "tproxy.yml")
                yamlFile.writeText(
                    """
                    tunnel:
                      name: tun0
                      mtu: $mtu
                      multi-queue: false
                      ipv4: 198.18.0.1
                      icmp: 'reply'
                    socks5:
                      port: $SOCKS_PORT
                      address: 127.0.0.1
                      udp: 'udp'
                    misc:
                      task-stack-size: 86016
                      connect-timeout: 10000
                      tcp-read-write-timeout: 300000
                      udp-read-write-timeout: 60000
                    """.trimIndent()
                )

                val started = TProxyService.TProxyStartService(yamlFile.absolutePath, pfd.fd)
                if (!started) {
                    throw IllegalStateException("راه‌اندازی موتور hev-socks5-tunnel ناموفق بود.")
                }

                updateNotification("متصل · Aether (${protocol.uppercase()})")
                emitState("connected", "تونل Aether (${protocol.uppercase()}) برقرار شد ✅")
                startStatsPolling()

            } catch (e: Exception) {
                if (!stopping.get()) {
                    emitLog("ERROR: ${e.message}")
                    stopAetherTunnel("خطا در Aether: ${e.message ?: "نامشخص"}")
                }
            }
        }
    }

    private fun waitForSocksReady(proc: Process, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline && !stopping.get()) {
            if (!proc.isAlive) return false
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress("127.0.0.1", SOCKS_PORT), 350)
                }
                return true
            } catch (_: Exception) {
                try { Thread.sleep(250) } catch (_: InterruptedException) { return false }
            }
        }
        return false
    }

    private fun startStatsPolling() {
        stopStatsPolling()
        statsTask = statsScheduler.scheduleAtFixedRate({
            try {
                if (!isServiceRunning || stopping.get()) return@scheduleAtFixedRate
                if (aetherProcess?.isAlive == false) {
                    stopAetherTunnel("پروسه هسته Aether متوقف شد.")
                    return@scheduleAtFixedRate
                }
                val stats = TProxyService.TProxyGetStats()
                if (stats.size >= 4) {
                    val txBytes = stats[1]
                    val rxBytes = stats[3]
                    sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
                        putExtra(EVENT_TYPE, "stats")
                        putExtra(EVENT_RX, rxBytes)
                        putExtra(EVENT_TX, txBytes)
                    })
                }
            } catch (_: Exception) {
            }
        }, 400, 1000, TimeUnit.MILLISECONDS)
    }

    private fun stopStatsPolling() {
        statsTask?.cancel(false)
        statsTask = null
    }

    private fun cleanupCoreOnly() {
        stopStatsPolling()
        try {
            if (TProxyService.TProxyIsRunning()) {
                TProxyService.TProxyStopService()
            }
        } catch (_: Exception) {
        }
        try { tunInterface?.close() } catch (_: Exception) {}
        tunInterface = null
        try {
            aetherProcess?.let { p ->
                p.destroy()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && p.isAlive) {
                    p.destroyForcibly()
                }
            }
        } catch (_: Exception) {}
        aetherProcess = null
    }

    private fun stopAetherTunnel(reason: String) {
        if (stopping.getAndSet(true)) return
        workerExecutor.execute {
            cleanupCoreOnly()
            isServiceRunning = false
            emitState("disconnected", reason)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    private fun emitState(state: String, msg: String?) {
        currentState = state
        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
            putExtra(EVENT_TYPE, "state")
            putExtra(EVENT_STATE, state)
            if (msg != null) putExtra(EVENT_MESSAGE, msg)
        })
    }

    private fun emitLog(msg: String) {
        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
            putExtra(EVENT_TYPE, "log")
            putExtra(EVENT_MESSAGE, msg)
        })
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                CHANNEL_ID,
                "NovaGuard Aether VPN",
                NotificationManager.IMPORTANCE_LOW
            )
            nm?.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val pendingOpen = PendingIntent.getActivity(this, 0, openIntent, flags)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("NovaGuard")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pendingOpen)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.notify(NOTIF_ID, buildNotification(text))
        } catch (_: Exception) {
        }
    }

    override fun onRevoke() {
        stopAetherTunnel("مجوز VPN لغو شد.")
        super.onRevoke()
    }

    override fun onDestroy() {
        stopping.set(true)
        cleanupCoreOnly()
        isServiceRunning = false
        currentState = "disconnected"
        workerExecutor.shutdownNow()
        statsScheduler.shutdownNow()
        super.onDestroy()
    }
}
