package com.tunweb.wireguard

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var backend: GoBackend
    private lateinit var tunnel: WgTunnel

    private val mainHandler = Handler(Looper.getMainLooper())
    private val wgExecutor = Executors.newSingleThreadExecutor()
    private val statsScheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var statsTask: ScheduledFuture<*>? = null

    private var pendingConfigText: String? = null
    private var pendingProfileName: String = "TunWeb"
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            pendingConfigText?.let { startTunnelInternal(it, pendingProfileName) }
        } else {
            notifyJsState("disconnected", "مجوز ساخت VPN توسط کاربر رد شد.")
        }
        pendingConfigText = null
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val uris = if (result.resultCode == Activity.RESULT_OK && data?.data != null) {
            arrayOf(data.data!!)
        } else {
            null
        }
        fileUploadCallback?.onReceiveValue(uris)
        fileUploadCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        backend = GoBackend(applicationContext)
        tunnel = WgTunnel("TunWeb") { newState ->
            val stateStr = when (newState) {
                Tunnel.State.UP -> "connected"
                Tunnel.State.DOWN -> "disconnected"
                else -> "connecting"
            }
            if (newState == Tunnel.State.UP) startStatsLoop() else stopStatsLoop()
            notifyJsState(stateStr, null)
        }

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                fileChooserLauncher.launch(Intent.createChooser(intent, "انتخاب فایل .conf"))
                return true
            }
        }

        webView.addJavascriptInterface(AndroidVpnBridge(), "AndroidVpn")
        webView.loadUrl("file:///android_asset/www/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun startTunnelInternal(configText: String, profileName: String) {
        wgExecutor.execute {
            try {
                tunnel.setName(profileName)
                val config = Config.parse(ByteArrayInputStream(configText.toByteArray(Charsets.UTF_8)))
                backend.setState(tunnel, Tunnel.State.UP, config)
                notifyJsState("connected", "تونل WireGuard با موفقیت برقرار شد.")
                startStatsLoop()
            } catch (e: Exception) {
                stopStatsLoop()
                notifyJsState("disconnected", "خطا در اتصال: ${e.message ?: "نامشخص"}")
            }
        }
    }

    private fun stopTunnelInternal() {
        stopStatsLoop()
        wgExecutor.execute {
            try {
                backend.setState(tunnel, Tunnel.State.DOWN, null)
                notifyJsState("disconnected", "تونل قطع شد.")
            } catch (e: Exception) {
                notifyJsState("disconnected", "خطا در قطع اتصال: ${e.message}")
            }
        }
    }

    private fun startStatsLoop() {
        stopStatsLoop()
        statsTask = statsScheduler.scheduleAtFixedRate({
            try {
                val stats = backend.getStatistics(tunnel)
                val rx = stats.totalRx()
                val tx = stats.totalTx()
                var latestHs = 0L
                for (peerKey in stats.peers()) {
                    val peerStats = stats.peer(peerKey)
                    if (peerStats != null && peerStats.latestHandshakeEpochMillis > latestHs) {
                        latestHs = peerStats.latestHandshakeEpochMillis
                    }
                }
                mainHandler.post {
                    webView.evaluateJavascript("window.onVpnStats($rx, $tx, $latestHs);", null)
                }
            } catch (_: Exception) {
            }
        }, 500, 1000, TimeUnit.MILLISECONDS)
    }

    private fun stopStatsLoop() {
        statsTask?.cancel(false)
        statsTask = null
    }

    private fun notifyJsState(state: String, message: String?) {
        val stateJson = JSONObject.quote(state)
        val msgJson = if (message != null) JSONObject.quote(message) else "null"
        mainHandler.post {
            webView.evaluateJavascript("window.onVpnStateChanged($stateJson, $msgJson);", null)
        }
    }

    override fun onDestroy() {
        stopStatsLoop()
        wgExecutor.shutdownNow()
        statsScheduler.shutdownNow()
        super.onDestroy()
    }

    inner class AndroidVpnBridge {
        @JavascriptInterface
        fun connect(configText: String, profileName: String) {
            mainHandler.post {
                val prepareIntent = VpnService.prepare(this@MainActivity)
                if (prepareIntent != null) {
                    pendingConfigText = configText
                    pendingProfileName = profileName
                    vpnPermissionLauncher.launch(prepareIntent)
                } else {
                    startTunnelInternal(configText, profileName)
                }
            }
        }

        @JavascriptInterface
        fun disconnect() {
            stopTunnelInternal()
        }
    }
}
