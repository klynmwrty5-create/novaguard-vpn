package com.tunweb.wireguard

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.ConnectException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var backend: GoBackend
    private lateinit var tunnel: WgTunnel

    private val mainHandler = Handler(Looper.getMainLooper())
    private val wgExecutor = Executors.newSingleThreadExecutor()
    private val pingExecutor = Executors.newCachedThreadPool()
    private val statsScheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var statsTask: ScheduledFuture<*>? = null

    private var pendingConfigText: String? = null
    private var pendingProfileName: String = "NovaGuard"
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            pendingConfigText?.let { startTunnelInternal(it, pendingProfileName) }
        } else {
            notifyJsState("disconnected", "مجوز برقراری VPN تأیید نشد.")
        }
        pendingConfigText = null
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val uris = if (result.resultCode == Activity.RESULT_OK && data?.data != null) {
            arrayOf(data.data!!)
        } else {
            null
        }
        fileUploadCallback?.onReceiveValue(uris)
        fileUploadCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        backend = GoBackend(applicationContext)
        tunnel = WgTunnel("NovaGuard") { newState ->
            val stateStr = when (newState) {
                Tunnel.State.UP -> "connected"
                Tunnel.State.DOWN -> "disconnected"
                else -> "connecting"
            }
            if (newState == Tunnel.State.UP) startStatsLoop() else stopStatsLoop()
            notifyJsState(stateStr, null)
        }

        webView = WebView(this).apply {
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
            }
        }
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                fileChooserLauncher.launch(Intent.createChooser(intent, "انتخاب فایل کانفیگ .conf"))
                return true
            }
        }

        webView.addJavascriptInterface(AndroidVpnBridge(), "AndroidVpn")
        webView.loadUrl("file:///android_asset/www/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        syncRunningState()
    }

    override fun onPause() {
        // Free CPU & battery in background so GoBackend encryption runs at maximum throughput
        stopStatsLoop()
        super.onPause()
    }

    private fun syncRunningState() {
        wgExecutor.execute {
            try {
                val running = backend.runningTunnelNames
                if (running.isNotEmpty()) {
                    tunnel.setName(running.first())
                    notifyJsState("connected", null)
                    startStatsLoop()
                } else {
                    stopStatsLoop()
                    notifyJsState("disconnected", null)
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun startTunnelInternal(configText: String, profileName: String) {
        wgExecutor.execute {
            try {
                tunnel.setName(profileName)
                val config = Config.parse(ByteArrayInputStream(configText.toByteArray(Charsets.UTF_8)))
                backend.setState(tunnel, Tunnel.State.UP, config)
                notifyJsState("connected", "اتصال امن با موفقیت برقرار شد.")
                startStatsLoop()
            } catch (e: Exception) {
                stopStatsLoop()
                notifyJsState("disconnected", "خطا در اتصال: ${e.message ?: "نامشخص"}")
            }
        }
    }

    private fun stopTunnelInternal() {
        stopStatsLoop()
        wgExecutor.execute {
            try {
                backend.setState(tunnel, Tunnel.State.DOWN, null)
                notifyJsState("disconnected", "اتصال قطع شد.")
            } catch (e: Exception) {
                notifyJsState("disconnected", "خطا در قطع اتصال: ${e.message}")
            }
        }
    }

    private fun startStatsLoop() {
        stopStatsLoop()
        statsTask = statsScheduler.scheduleAtFixedRate({
            try {
                val stats = backend.getStatistics(tunnel)
                val rx = stats.totalRx()
                val tx = stats.totalTx()
                var latestHs = 0L
                for (peerKey in stats.peers()) {
                    val peerStats = stats.peer(peerKey)
                    if (peerStats != null && peerStats.latestHandshakeEpochMillis > latestHs) {
                        latestHs = peerStats.latestHandshakeEpochMillis
                    }
                }
                mainHandler.post {
                    webView.evaluateJavascript("window.onVpnStats($rx, $tx, $latestHs);", null)
                }
            } catch (_: Exception) {
            }
        }, 400, 1000, TimeUnit.MILLISECONDS)
    }

    private fun stopStatsLoop() {
        statsTask?.cancel(false)
        statsTask = null
    }

    private fun notifyJsState(state: String, message: String?) {
        val stateJson = JSONObject.quote(state)
        val msgJson = if (message != null) JSONObject.quote(message) else "null"
        mainHandler.post {
            webView.evaluateJavascript("window.onVpnStateChanged($stateJson, $msgJson);", null)
        }
    }

    override fun onDestroy() {
        stopStatsLoop()
        wgExecutor.shutdownNow()
        pingExecutor.shutdownNow()
        statsScheduler.shutdownNow()
        super.onDestroy()
    }

    inner class AndroidVpnBridge {
        @JavascriptInterface
        fun connect(configText: String, profileName: String) {
            mainHandler.post {
                val prepareIntent = VpnService.prepare(this@MainActivity)
                if (prepareIntent != null) {
                    pendingConfigText = configText
                    pendingProfileName = profileName
                    vpnPermissionLauncher.launch(prepareIntent)
                } else {
                    startTunnelInternal(configText, profileName)
                }
            }
        }

        @JavascriptInterface
        fun disconnect() {
            stopTunnelInternal()
        }

        @JavascriptInterface
        fun syncState() {
            syncRunningState()
        }

        @JavascriptInterface
        fun pingEndpoint(endpoint: String, profileId: String) {
            pingExecutor.execute {
                var rttMs = -1L
                try {
                    val clean = endpoint.trim()
                    val host: String
                    val port: Int
                    if (clean.startsWith("[")) {
                        val endBracket = clean.indexOf(']')
                        host = clean.substring(1, endBracket)
                        port = clean.substring(endBracket + 2).toIntOrNull() ?: 51820
                    } else {
                        val idx = clean.lastIndexOf(':')
                        host = if (idx > 0) clean.substring(0, idx) else clean
                        port = if (idx > 0) (clean.substring(idx + 1).toIntOrNull() ?: 51820) else 51820
                    }

                    val addr = InetAddress.getByName(host)
                    // Try quick TCP RTT (ConnectException RST also gives accurate RTT)
                    val portsToTry = listOf(port, 443, 80)
                    for (p in portsToTry) {
                        val t0 = System.nanoTime()
                        try {
                            Socket().use { sock ->
                                sock.connect(InetSocketAddress(addr, p), 1200)
                            }
                            rttMs = ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L)
                            break
                        } catch (_: ConnectException) {
                            rttMs = ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L)
                            break
                        } catch (_: Exception) {
                        }
                    }
                    if (rttMs < 0) {
                        val t0 = System.nanoTime()
                        if (addr.isReachable(1200)) {
                            rttMs = ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L)
                        }
                    }
                } catch (_: Exception) {
                    rttMs = -1L
                }

                val idJson = JSONObject.quote(profileId)
                mainHandler.post {
                    webView.evaluateJavascript("window.onPingResult($idJson, $rttMs);", null)
                }
            }
        }

        @JavascriptInterface
        fun readClipboard(): String {
            return try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    clip.getItemAt(0).coerceToText(this@MainActivity).toString()
                } else ""
            } catch (_: Exception) {
                ""
            }
        }

        @JavascriptInterface
        fun exportConfig(filename: String, content: String) {
            mainHandler.post {
                try {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, filename)
                        putExtra(Intent.EXTRA_TEXT, content)
                    }
                    startActivity(Intent.createChooser(shareIntent, "اشتراک‌گذاری یا ذخیره کانفیگ"))
                } catch (_: Exception) {
                }
            }
        }
    }
}
